package com.musicplayer.promax.playback

import android.os.SystemClock
import androidx.media3.common.Player
import com.musicplayer.promax.data.local.MusicLibraryDatabase
import com.musicplayer.promax.data.stats.PlaybackHistoryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Records audible segments without blocking the playback thread. */
class PlaybackHistoryRecorder(
    private val database: MusicLibraryDatabase
) : Player.Listener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var currentTrackKey: String? = null
    private var segmentStartedAtElapsed: Long? = null
    private var segmentStartedAtWall: Long = 0L
    private var countedThisVisit = false

    override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
        finishSegment()
        currentTrackKey = mediaItem?.mediaId?.takeIf(String::isNotBlank)
        countedThisVisit = false
        if (mediaItem != null) beginSegmentIfPlaying()
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        if (isPlaying) beginSegmentIfPlaying() else finishSegment()
    }

    override fun onPlaybackStateChanged(playbackState: Int) {
        if (playbackState == Player.STATE_ENDED || playbackState == Player.STATE_IDLE) finishSegment()
    }

    private fun beginSegmentIfPlaying() {
        if (segmentStartedAtElapsed != null) return
        val key = currentTrackKey ?: return
        segmentStartedAtElapsed = SystemClock.elapsedRealtime()
        segmentStartedAtWall = System.currentTimeMillis()
        if (!countedThisVisit) {
            countedThisVisit = true
            pendingPlayCount = true
        }
    }

    private fun finishSegment() {
        val started = segmentStartedAtElapsed ?: return
        val key = currentTrackKey
        segmentStartedAtElapsed = null
        val duration = (SystemClock.elapsedRealtime() - started).coerceAtLeast(0L)
        if (key.isNullOrBlank() || duration <= 0L) return
        // The visit is counted on its first audible segment only.
        val shouldCount = pendingPlayCount
        pendingPlayCount = false
        val playedAt = segmentStartedAtWall
        scope.launch {
            val dao = database.playbackStatsDao()
            dao.insertSegment(PlaybackHistoryEntity(trackKey = key, playedAt = playedAt, listenedMs = duration, playCount = if (shouldCount) 1 else 0))
            dao.pruneBefore(System.currentTimeMillis() - RETENTION_DAYS * DAY_MS)
        }
    }

    private var pendingPlayCount: Boolean = false

    fun onInitialPlaybackState(player: Player) {
        currentTrackKey = player.currentMediaItem?.mediaId?.takeIf(String::isNotBlank)
        if (player.isPlaying) beginSegmentIfPlaying()
    }

    override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) = Unit

    fun release() {
        finishSegment()
    }

    companion object {
        private const val RETENTION_DAYS = 365L
        private const val DAY_MS = 86_400_000L
    }
}
