# Known Issues / Verification Gaps

1. Gradle build and APK/AAB generation have not been run, per the user's instruction. No successful Android build is claimed.
2. Android emulator/physical-device behavior remains unverified: permission prompts, MediaStore, SD-card volume discovery, SAF access, WorkManager, ContentObserver, background playback, audio focus, notification/lock-screen controls, audio effects, sleep timer, and widget actions.
3. The repository uses a lightweight custom `gradlew` bootstrap script rather than the official Gradle Wrapper JAR. Replace it with a standard wrapper when a trusted Gradle installation is available and the user authorizes build-tool work.
4. SAF indexing enumerates the selected directory tree on each update, while avoiding database writes for unchanged files. Provider enumeration time depends on the SD card and document provider.
5. SAF fallback rows currently use filename and file facts; embedded tag/artwork extraction behavior for SAF URIs still needs device validation.
6. Application ID `com.musicplayer.promax` remains provisional.
7. Library queries currently materialize all matching tracks into a `List`; Paging 3 is not integrated. Very large libraries may increase memory use and UI update cost.
8. Notification artwork may not update on the active MediaSession item when artwork is extracted for the first time during playback; see Phase 8 limitations.
9. Playback format coverage depends on Media3/device decoders and actual codecs inside the files.
10. Room schema export directory is empty because annotation processing/build has not been run. Generate schema snapshots and verify migrations 1→2→3→4 in an Android build environment.
11. App-local metadata overrides do not rewrite embedded tags in original audio files.
12. Artwork extraction occurs on demand when a track is played; it is not a full-library batch process. Files without embedded cover art retain the vinyl fallback.
13. LRC files must be imported manually. Automatic sibling-file matching is not implemented.
14. Play signing, release configuration, store listing, privacy policy, data-safety declarations, and store assets remain outstanding.
