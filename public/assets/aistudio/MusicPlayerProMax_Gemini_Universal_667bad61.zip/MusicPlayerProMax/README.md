# Music Player Pro Max

An offline-first Android local music player built with Kotlin, Jetpack Compose, Material 3, Room, WorkManager, and Media3.

## Implemented source phases

1. Foundation, localization, design tokens, settings persistence, and navigation.
2. Premium UI foundation and main app screens.
3. Local music discovery and indexing through MediaStore and SAF, with Room-backed catalog and background work.
4. Media3 playback service, MediaSession, background playback, audio focus handling, and mini-player.
5. Full-screen Now Playing experience with seeking, transport controls, shuffle/repeat, and vinyl-inspired motion.
6. Device-supported Equalizer, BassBoost, Virtualizer, and presets.
7. Room-backed playlists and favorites, search, sorting, and playlist playback.
8. Embedded artwork extraction/cache, app-local metadata overrides, imported LRC lyrics, and lyric synchronization.
9. Listening statistics, sleep timer, accent customization, and home-screen widget.
10. Code-level integration review and static quality corrections; Android build/device/release validation remains pending.

## Current verification boundary

- Gradle has intentionally **not** been run in this environment, per the user's instruction.
- No APK or AAB is claimed to have been generated.
- No emulator or physical-device validation is claimed.
- XML parsing, localization consistency, SQL smoke checks, and ZIP integrity checks were performed for the Phase 10 code-level review.
- Android compilation, Room schema export/migration verification, instrumentation tests, and device compatibility remain outstanding.

See `project_docs/PHASE_10_FINAL_REVIEW.md`, `PROJECT_STATUS.md`, and `KNOWN_ISSUES.md` for current status and limitations.
